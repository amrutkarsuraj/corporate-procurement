import 'package:dio/dio.dart';

import '../constants/api_constants.dart';
import 'dio_interceptor.dart';

class DioClient {
  late final Dio dio;

  DioClient() {
    dio = Dio(
      BaseOptions(
        baseUrl:
        ApiConstants.baseUrl,
        connectTimeout:
        const Duration(
          seconds: 30,
        ),
        receiveTimeout:
        const Duration(
          seconds: 30,
        ),
      ),
    );

    dio.interceptors.add(
      DioInterceptor(),
    );
  }
}